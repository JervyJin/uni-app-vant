//线上
// var baseurl='http://27.50.132.78:8083/app/bxApp';
// var baseurl='http://192.168.0.117:8080/system';

var baseurl='http://zm.dangjian.link';
 // var baseurl='http://192.168.0.117:8080/system';


export default{
	baseurl
}
